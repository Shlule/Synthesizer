#pragma once
#include<vector>
#include"Note.h"
#include"InstrumentBase.h"


using std::vector;


class Synthesizer
{
public:
	vector<Note> vecNote;
	InstrumentBase harmonica = InstrumentBase{ 1.0 };
};

