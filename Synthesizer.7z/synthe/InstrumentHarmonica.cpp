#include "InstrumentHarmonica.h"

InstrumentHarmonica::InstrumentHarmonica(double dVolumeP) : InstrumentBase(dVolumeP) {

}