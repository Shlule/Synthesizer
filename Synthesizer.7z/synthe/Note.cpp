#include "Note.h"
Note::Note(int idP, int channelP) : id{ idP }, channel{ channelP } {

}
