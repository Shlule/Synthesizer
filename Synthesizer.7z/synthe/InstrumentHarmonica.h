#pragma once
#include"InstrumentBase.h"
class InstrumentHarmonica : public InstrumentBase
{
	InstrumentHarmonica(double dVolumeP);
};

