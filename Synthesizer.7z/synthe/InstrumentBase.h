#pragma once
#include<cmath>
#include<atomic>
#include"EnveloppeADSR.h"

class Note;


enum class OscType
{
	OSC_SINE,
	OSC_SQUARE,
	OSC_TRIANGLE,
	OSC_SAW_ANA,
	OSC_SAW_DIG,
	OSC_NOISE
};

class InstrumentBase
{
public:
	InstrumentBase(double dVolumeP);

	//convert Frequency to angular velocity
	double freqToAngularVelo(double dHertzP);
	double oscillator(const double dTimeP, const double dHertzP, const OscType nTypeP = OscType::OSC_SINE, const double dLFOHertzP = 0.0, const double dLFOAmplitudeP = 0.0, double dCustomP =50.0);

	virtual double sound(const double dTimeP, Note n, bool& bNoteFinished) = 0;


private:
	
	double dVolume;
	EnveloppeADSR env = EnveloppeADSR{ 0.0, 0.0, 0.0, 0.0, 0.0 };

	double PI = 2.0 * acos(0.0);
};

