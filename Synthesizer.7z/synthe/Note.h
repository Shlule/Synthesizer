#pragma once
class Note
{
public:

	Note(int idP, int channelP);

	int id;
	double timeActivated{ 0.0 };
	double timeDeactivated{ 0.0 };
	bool isActive{ false };
	int channel;
};

